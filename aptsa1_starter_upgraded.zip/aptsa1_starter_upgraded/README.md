# APTSA1 Governance Starter
**Version 0.2.0**

Entry-point implementation of the APTSA1 governance architecture.

Created by Leon George | Y✶KNOT AI CONSULTANT LTD (Company No. 17128151)
Patent: GB2521334.9 (priority date 10 December 2025, active at UKIPO)

---

## What This Is

A modular, developer-friendly entry point to APTSA1 governance.

This starter kit is suitable for evaluation, integration testing, and
sector-specific development. For full production deployment — including
PostgreSQL ledger, Redis rate limiting, scrypt RBAC, Prometheus
observability, and Ed25519 SEAL quorum gate — see:

**`aptsa1_universal.py`** (production build)

---

## What's In Here

| Module | Function |
|---|---|
| `app/core12.py` | CORE12 twelve needs — invariant, SHA-256 fingerprinted |
| `app/policy.py` | ICS Policy Engine — CORE12 + sector invariant checks |
| `app/contract.py` | Synthetic Contract — APTSA1 field-by-field drift + adjudication |
| `app/ledger.py` | Signed append-only JSON ledger (Ed25519) |
| `app/integrity.py` | Active FORTIFY-style integrity daemon |
| `app/approvals.py` | SEAL gate — role-gated approval records |
| `app/sandbox.py` | Capability gating |
| `app/explain.py` | LASTExplainer — human-readable decision explanation |
| `app/adapters/` | OpenAI-like and HTTP action adapters |
| `app/compliance/` | DTAC and OWASP Agentic Top 10 scaffold |
| `benchmarks/` | Performance benchmark harness |
| `sdk/typescript/` | TypeScript client stub |
| `sdk/dotnet/` | C# client stub |
| `tests/` | Contract test suite |

---

## Decision Ladder

```
CORE12 fingerprint tampered  →  HALT
Critical policy violation    →  HALT or DENY
Forbidden action             →  HALT
Capability denied            →  DENY
Approval required            →  PENDING_APPROVAL
Drift ≥ 0.4 or warnings      →  DEGRADE
Otherwise                    →  ALLOW
```

---

## Drift Detection

APTSA1 field-by-field semantic comparison across four dimensions:

| Field | Weight |
|---|---|
| goal | 0.5 |
| scope | 0.2 |
| consent_basis | 0.2 |
| target_subject | 0.1 |

Pass structured `declared_intent` and `observed_action` dicts for
full drift detection. Plain strings are treated as goal-only.

---

## Quick Start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Endpoints:
- `GET /health` — system status and integrity check
- `POST /v1/decide` — governance decision
- `GET /v1/core12` — CORE12 fingerprint and needs
- `GET /v1/ledger/verify` — verify ledger chain integrity
- `POST /v1/approvals/create` — create pending approval (SEAL gate)
- `POST /v1/approvals/{id}/approve` — approve with role verification
- `GET /v1/compliance` — DTAC and OWASP mapping scaffolds

---

## Example Request

```json
{
  "action": "dispatch_message",
  "declared_intent": {
    "goal": "Send appointment reminder",
    "scope": "single_patient",
    "consent_basis": "confirmed"
  },
  "observed_action": {
    "goal": "Send appointment reminder",
    "scope": "single_patient",
    "consent_basis": "confirmed"
  },
  "context": {
    "contains_personal_data": true,
    "consent_basis": "confirmed"
  },
  "core12_harms": {
    "health": false,
    "security": false
  },
  "requested_capabilities": ["send_message"]
}
```

---

## Upgrading to Production

This starter uses a JSON file ledger and in-memory approvals.
For production:

- Swap JSON ledger → PostgreSQL (see `aptsa1_universal.py`)
- Add Redis rate limiting
- Add scrypt RBAC with role verification
- Add Prometheus observability
- Add full SEAL quorum approval gate
- Add CORS hardening and API token auth

---

## Intellectual Property

Patent GB2521334.9 covers six named components of the APTSA1
architecture (priority date 10 December 2025, active at UKIPO).

CORE12 is the original work of Leon George, developed over 29 years.

This starter is released under Apache 2.0. The interpretive framework —
how CORE12 applies to your sector — is the proprietary consulting layer
available through Y✶KNOT AI CONSULTANT LTD.

https://aptsa1-runtime.emergent.host
