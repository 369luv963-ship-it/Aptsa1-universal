from __future__ import annotations

from .models import ActionRequest, ApprovalAssessment, DriftAssessment, PolicyAssessment, SandboxAssessment


def render_explanation(
    decision: str,
    request: ActionRequest,
    policy: PolicyAssessment,
    drift: DriftAssessment,
    sandbox: SandboxAssessment,
    approval: ApprovalAssessment,
) -> str:
    lines = [
        f"Decision: {decision}.",
        f"Action: {request.action}.",
    ]
    harmed = request.core12_harms.harmed_needs()
    if harmed:
        lines.append(f"CORE12 impact flagged for: {', '.join(harmed)}.")
    if policy.critical:
        lines.append(f"Critical policy findings: {' | '.join(policy.critical)}.")
    if policy.violations:
        lines.append(f"Violations: {' | '.join(policy.violations)}.")
    if policy.warnings:
        lines.append(f"Warnings: {' | '.join(policy.warnings)}.")
    if drift.reasons:
        lines.append(f"Drift: {' | '.join(drift.reasons)}.")
    if sandbox.reasons:
        lines.append(f"Sandbox: {' | '.join(sandbox.reasons)}.")
    if approval.reasons:
        lines.append(f"Approval: {' | '.join(approval.reasons)}.")
    return " ".join(lines)
