from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional

from .core12 import sha256_hex, stable_json

_STORE: dict[str, "ApprovalRecord"] = {}
_LOCK = threading.Lock()

VALID_ROLES = {"approver", "safety_officer", "admin"}


@dataclass(slots=True)
class ApprovalRecord:
    decision_ref: str
    requested_by: str
    reason: str
    required_role: str = "approver"
    approvers: list[str] = field(default_factory=list)
    approved_roles: list[str] = field(default_factory=list)
    state: str = "pending"  # pending | approved | rejected


def create_approval(
    decision_ref: str,
    requested_by: str,
    reason: str,
    required_role: str = "approver",
) -> str:
    """
    Create a pending approval record. Returns a record ID (SHA-256 of inputs).
    Mirrors APTSA1 SEAL gate — no approval can be silent or unlogged.
    """
    record_id = sha256_hex(stable_json({
        "decision_ref": decision_ref,
        "requested_by": requested_by,
        "reason": reason,
    }))[:16]
    with _LOCK:
        _STORE[record_id] = ApprovalRecord(
            decision_ref=decision_ref,
            requested_by=requested_by,
            reason=reason,
            required_role=required_role,
        )
    return record_id


def approve(record_id: str, approver: str, role: str) -> Optional[ApprovalRecord]:
    """
    Approve a pending record. Role must satisfy required_role or be admin.
    Returns None if record not found or role insufficient.
    """
    with _LOCK:
        record = _STORE.get(record_id)
        if not record:
            return None
        if role not in VALID_ROLES:
            return None
        if record.required_role != role and role != "admin":
            return None
        if record.state != "pending":
            return record
        record.approvers.append(approver)
        record.approved_roles.append(role)
        record.state = "approved"
        return record


def get_approval(record_id: str) -> Optional[ApprovalRecord]:
    with _LOCK:
        return _STORE.get(record_id)
