from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .config import settings
from .core12 import sha256_hex, stable_json


def load_or_create_signing_key() -> Ed25519PrivateKey:
    pem = None
    try:
        import os
        pem = os.getenv("APTSA1_SIGNING_KEY_PEM")
    except Exception:
        pem = None
    if pem:
        return serialization.load_pem_private_key(pem.encode("utf-8"), password=None)  # type: ignore[return-value]

    key_path = Path("aptsa1_cleanroom_signing.key")
    if key_path.exists():
        return serialization.load_pem_private_key(key_path.read_bytes(), password=None)  # type: ignore[return-value]

    key = Ed25519PrivateKey.generate()
    key_path.write_bytes(
        key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    key_path.with_suffix(".pub").write_bytes(
        key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )
    return key


_SIGNING_KEY = load_or_create_signing_key()
_VERIFY_KEY: Ed25519PublicKey = _SIGNING_KEY.public_key()


def verify_signature(message: bytes, signature_b64: str) -> bool:
    try:
        _VERIFY_KEY.verify(base64.b64decode(signature_b64), message)
        return True
    except Exception:
        return False


class SignedLedger:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or settings.ledger_path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)

    def _last_hash(self) -> str:
        lines = self.path.read_text(encoding="utf-8").splitlines()
        if not lines:
            return "GENESIS"
        last = json.loads(lines[-1])
        return str(last["entry_hash"])

    def append(self, event_type: str, payload: dict[str, Any]) -> str:
        envelope = {
            "event_type": event_type,
            "payload": payload,
            "prev_hash": self._last_hash(),
        }
        message = stable_json(envelope).encode("utf-8")
        signature = base64.b64encode(_SIGNING_KEY.sign(message)).decode("ascii")
        entry_hash = sha256_hex(message + signature.encode("utf-8"))
        record = {
            **envelope,
            "signature_b64": signature,
            "entry_hash": entry_hash,
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(stable_json(record) + "\n")
        return entry_hash

    def verify(self) -> bool:
        prev = "GENESIS"
        for line in self.path.read_text(encoding="utf-8").splitlines():
            record = json.loads(line)
            envelope = {
                "event_type": record["event_type"],
                "payload": record["payload"],
                "prev_hash": record["prev_hash"],
            }
            if record["prev_hash"] != prev:
                return False
            message = stable_json(envelope).encode("utf-8")
            if not verify_signature(message, record["signature_b64"]):
                return False
            expected_hash = sha256_hex(message + record["signature_b64"].encode("utf-8"))
            if record["entry_hash"] != expected_hash:
                return False
            prev = record["entry_hash"]
        return True
