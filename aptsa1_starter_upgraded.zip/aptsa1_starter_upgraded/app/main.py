from __future__ import annotations

from pathlib import Path

import yaml
from fastapi import FastAPI, HTTPException

from .approvals import approve, create_approval, get_approval
from .contract import decide
from .core12 import CORE12, CORE12_FINGERPRINT
from .integrity import IntegrityMonitor
from .ledger import SignedLedger
from .models import ActionRequest, HealthResponse

app = FastAPI(
    title="APTSA1 Governance Starter",
    version="0.2.0",
    description=(
        "Entry-point governance engine built on APTSA1 architecture. "
        "Patent GB2521334.9 | Leon George / Y\u204eKNOT AI CONSULTANT LTD. "
        "For production deployment see aptsa1_universal.py."
    ),
)

ledger = SignedLedger()
integrity = IntegrityMonitor()
integrity.start()


@app.on_event("shutdown")
def on_shutdown() -> None:
    integrity.stop()


@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    checks = {
        "integrity_snapshot_valid": integrity.verify(),
        "integrity_breach_detected": not integrity.breach_detected,
        "ledger_chain_valid": ledger.verify(),
        "core12_fingerprint_present": bool(CORE12_FINGERPRINT),
    }
    return HealthResponse(
        status="ok" if all(checks.values()) else "degraded",
        checks=checks,
    )


@app.post("/v1/decide")
def decide_action(request: ActionRequest):
    response = decide(request)
    ledger_hash = ledger.append(
        "decision_made",
        {
            "action": request.action,
            "decision": response.decision,
            "reasons": response.reasons,
            "core12_fingerprint": response.core12_fingerprint,
            "context": request.context,
        },
    )
    response.ledger_hash = ledger_hash
    return response


@app.post("/v1/approvals/create")
def create_approval_record(
    decision_ref: str,
    requested_by: str,
    reason: str,
    required_role: str = "approver",
):
    """Create a pending approval. Mirrors APTSA1 SEAL gate."""
    record_id = create_approval(decision_ref, requested_by, reason, required_role)
    return {"ok": True, "record_id": record_id}


@app.post("/v1/approvals/{record_id}/approve")
def approve_record(record_id: str, approver: str, role: str):
    """Approve a pending decision. Role-gated — no silent approvals."""
    record = approve(record_id, approver, role)
    if record is None:
        raise HTTPException(status_code=403, detail="Approval failed — record not found or role insufficient.")
    return {"ok": True, "state": record.state, "approved_by": record.approvers}


@app.get("/v1/approvals/{record_id}")
def get_approval_record(record_id: str):
    record = get_approval(record_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Approval record not found.")
    return record


@app.get("/v1/core12")
def core12_info():
    return {
        "needs": list(CORE12),
        "fingerprint": CORE12_FINGERPRINT,
        "invariant": True,
        "description": (
            "Twelve universal human needs. Invariant across all sectors. "
            "Any action that harms one or more activates enforcement. "
            "Cannot be modified, reordered, or overridden at runtime."
        ),
    }


@app.get("/v1/ledger/verify")
def verify_ledger():
    return {"ok": ledger.verify()}


@app.get("/v1/compliance")
def compliance_summary():
    base = Path(__file__).parent / "compliance"
    result = {}
    for name in ("dtac_support.yaml", "owasp_agentic_top10.yaml"):
        result[name] = yaml.safe_load((base / name).read_text(encoding="utf-8"))
    return result
