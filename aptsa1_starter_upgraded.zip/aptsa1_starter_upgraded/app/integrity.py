from __future__ import annotations

import os
import signal
import threading
import time
from pathlib import Path

from .config import settings
from .core12 import sha256_hex


class IntegrityMonitor:
    """
    Upgraded from passive snapshot check to active FORTIFY-style daemon.
    Watches its own files continuously. On breach: logs and optionally halts.
    APTSA1 FORTIFY principle: the governance engine cannot be silently tampered with.
    """

    def __init__(self, root: Path | None = None, interval_sec: int = 30, halt_on_breach: bool = False) -> None:
        self.root = (root or settings.integrity_root).resolve()
        self.interval_sec = interval_sec
        self.halt_on_breach = halt_on_breach
        self._snapshot: dict[str, str] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._breach_detected = False

    def _iter_files(self) -> list[Path]:
        return sorted(
            p for p in self.root.rglob("*")
            if p.is_file()
            and "__pycache__" not in p.parts
            and not p.name.endswith((".pyc", ".pyo"))
        )

    def _build_snapshot(self) -> dict[str, str]:
        snapshot: dict[str, str] = {}
        if not self.root.exists():
            return snapshot
        for path in self._iter_files():
            snapshot[str(path.relative_to(self.root))] = sha256_hex(path.read_bytes())
        return snapshot

    def start(self) -> None:
        """Take baseline snapshot and start background watch thread."""
        self._snapshot = self._build_snapshot()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        while not self._stop.is_set():
            time.sleep(self.interval_sec)
            current = self._build_snapshot()
            if current != self._snapshot:
                self._breach_detected = True
                if self.halt_on_breach:
                    os.kill(os.getpid(), signal.SIGTERM)

    def stop(self) -> None:
        self._stop.set()

    def verify(self) -> bool:
        """On-demand verification against baseline snapshot."""
        return self._snapshot == self._build_snapshot()

    @property
    def breach_detected(self) -> bool:
        return self._breach_detected
