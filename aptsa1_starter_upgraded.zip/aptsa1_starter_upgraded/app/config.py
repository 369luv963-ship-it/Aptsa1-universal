from __future__ import annotations

import json
import os
from pathlib import Path

from pydantic import BaseModel, Field


class Settings(BaseModel):
    strict_mode: bool = Field(default=os.getenv("APTSA1_STRICT_MODE", "true").lower() == "true")
    ledger_path: Path = Field(default=Path(os.getenv("APTSA1_LEDGER_PATH", "./ledger.jsonl")))
    integrity_root: Path = Field(default=Path(os.getenv("APTSA1_INTEGRITY_ROOT", "./app")))
    required_context_fields: list[str] = Field(
        default_factory=lambda: json.loads(os.getenv("APTSA1_REQUIRED_CONTEXT_FIELDS", '["consent_basis"]'))
    )
    approvals_required_actions: list[str] = Field(
        default_factory=lambda: [
            "override_consent",
            "delete_record",
            "suppress_alert",
            "disable_logging",
            "high_risk_outbound_action",
        ]
    )
    forbidden_actions: list[str] = Field(
        default_factory=lambda: [
            "disable_audit",
            "bypass_logging",
            "exfiltrate_secret",
        ]
    )
    default_sector_invariants: list[dict] = Field(
        default_factory=lambda: [
            {
                "name": "confirmed_consent_required_for_personal_data",
                "context_field": "consent_basis",
                "must_equal": "confirmed",
                "when": {"contains_personal_data": True},
                "severity": "critical",
            }
        ]
    )


settings = Settings()
