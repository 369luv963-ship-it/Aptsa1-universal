from __future__ import annotations

from .models import ActionRequest, SandboxAssessment


_ALLOWED_CAPABILITIES = {
    "read_context",
    "write_audit",
    "send_message",
    "query_model",
    "prepare_response",
}


class CapabilitySandbox:
    def assess(self, request: ActionRequest) -> SandboxAssessment:
        denied = sorted(set(request.requested_capabilities) - _ALLOWED_CAPABILITIES)
        if denied:
            return SandboxAssessment(
                allowed=False,
                denied_capabilities=denied,
                reasons=[f"Requested capability not permitted: {item}" for item in denied],
            )
        return SandboxAssessment(allowed=True, denied_capabilities=[], reasons=[])
