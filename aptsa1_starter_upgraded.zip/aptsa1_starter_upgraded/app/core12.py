from __future__ import annotations

import hashlib
import json
from typing import Final

CORE12: Final[tuple[str, ...]] = (
    "water",
    "food",
    "shelter",
    "clothing",
    "health",
    "companionship",
    "stimulation",
    "security",
    "income",
    "hope",
    "bonding",
    "procreation",
)


def stable_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(value: str | bytes) -> str:
    if isinstance(value, str):
        value = value.encode("utf-8")
    return hashlib.sha256(value).hexdigest()


CORE12_FINGERPRINT: Final[str] = sha256_hex(stable_json(CORE12))
