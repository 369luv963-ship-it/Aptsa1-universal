from __future__ import annotations

from typing import Any

from .base import ActionAdapter
from ..models import ActionRequest, Core12Harms


class HttpActionAdapter(ActionAdapter):
    name = "http_action"

    def normalise(self, payload: dict[str, Any]) -> ActionRequest:
        return ActionRequest(
            action=payload["action"],
            declared_intent=payload.get("declared_intent", ""),
            observed_action=payload.get("observed_action", payload["action"]),
            context=payload.get("context", {}),
            core12_harms=Core12Harms(**payload.get("core12_harms", {})),
            requested_capabilities=payload.get("requested_capabilities", []),
            require_explanation=payload.get("require_explanation", True),
        )
