from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..models import ActionRequest


class ActionAdapter(ABC):
    name: str

    @abstractmethod
    def normalise(self, payload: dict[str, Any]) -> ActionRequest:
        raise NotImplementedError
