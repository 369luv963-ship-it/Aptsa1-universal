from __future__ import annotations

from typing import Any

from .base import ActionAdapter
from ..models import ActionRequest


class OpenAILikeAdapter(ActionAdapter):
    name = "openai_like"

    def normalise(self, payload: dict[str, Any]) -> ActionRequest:
        messages = payload.get("messages", [])
        declared_intent = payload.get("metadata", {}).get("declared_intent", "")
        observed_action = "respond_to_messages"
        context = payload.get("metadata", {}).get("context", {})
        requested_capabilities = payload.get("metadata", {}).get("requested_capabilities", ["query_model"])
        return ActionRequest(
            action="model_response",
            declared_intent=declared_intent or f"Respond to {len(messages)} messages",
            observed_action=observed_action,
            context=context,
            requested_capabilities=requested_capabilities,
        )
