from __future__ import annotations

from .config import settings
from .models import ActionRequest, PolicyAssessment


def _conditions_match(context: dict, when: dict | None) -> bool:
    if not when:
        return True
    for key, expected in when.items():
        if context.get(key) != expected:
            return False
    return True


class PolicyEngine:
    @staticmethod
    def assess(request: ActionRequest, sector_invariants: list[dict] | None = None) -> PolicyAssessment:
        assessment = PolicyAssessment()
        harms = request.core12_harms.harmed_needs()
        if harms:
            assessment.critical.append(f"CORE12 harms detected: {', '.join(harms)}")

        invariants = sector_invariants or settings.default_sector_invariants
        for invariant in invariants:
            if not _conditions_match(request.context, invariant.get("when")):
                continue
            field_name = invariant.get("context_field")
            expected = invariant.get("must_equal")
            name = invariant.get("name", "unnamed_invariant")
            severity = invariant.get("severity", "violation")
            actual = request.context.get(field_name)
            if actual == expected:
                assessment.invariant_matches.append(name)
                continue
            message = f"Sector invariant failed: {name} (expected {field_name}={expected!r}, got {actual!r})"
            if severity == "critical":
                assessment.critical.append(message)
            else:
                assessment.violations.append(message)

        for field in settings.required_context_fields:
            if field not in request.context:
                assessment.violations.append(f"Required context missing: {field}")

        action = request.action.lower()
        if action in {a.lower() for a in settings.forbidden_actions}:
            assessment.critical.append(f"Forbidden action requested: {request.action}")

        if "secret" in action or "credential" in action:
            assessment.critical.append("Action appears to target secret or credential handling.")

        if request.context.get("contains_personal_data") and request.context.get("consent_basis") != "confirmed":
            assessment.critical.append("Personal-data action lacks confirmed consent basis.")

        if request.context.get("contains_personal_data") and not request.context.get("data_minimised", True):
            assessment.warnings.append("Data minimisation not confirmed.")

        return assessment
