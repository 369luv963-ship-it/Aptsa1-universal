from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from .core12 import CORE12


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Core12Harms(BaseModel):
    water: bool = False
    food: bool = False
    shelter: bool = False
    clothing: bool = False
    health: bool = False
    companionship: bool = False
    stimulation: bool = False
    security: bool = False
    income: bool = False
    hope: bool = False
    bonding: bool = False
    procreation: bool = False

    def harmed_needs(self) -> list[str]:
        return [need for need in CORE12 if getattr(self, need)]


class ActionRequest(BaseModel):
    action: str = Field(min_length=1)
    declared_intent: str = ""
    observed_action: str = ""
    context: dict[str, Any] = Field(default_factory=dict)
    core12_harms: Core12Harms = Field(default_factory=Core12Harms)
    requested_capabilities: list[str] = Field(default_factory=list)
    require_explanation: bool = True

    @model_validator(mode="after")
    def default_observed_action(self) -> "ActionRequest":
        if not self.observed_action:
            self.observed_action = self.action
        return self


class PolicyAssessment(BaseModel):
    critical: list[str] = Field(default_factory=list)
    violations: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    invariant_matches: list[str] = Field(default_factory=list)


class DriftAssessment(BaseModel):
    score: float = 0.0
    reasons: list[str] = Field(default_factory=list)


class SandboxAssessment(BaseModel):
    allowed: bool = True
    denied_capabilities: list[str] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)


class ApprovalAssessment(BaseModel):
    required: bool = False
    reasons: list[str] = Field(default_factory=list)


Decision = Literal["HALT", "DENY", "PENDING_APPROVAL", "DEGRADE", "ALLOW"]


class DecisionResponse(BaseModel):
    decision: Decision
    reasons: list[str] = Field(default_factory=list)
    policy: PolicyAssessment
    drift: DriftAssessment
    sandbox: SandboxAssessment
    approval: ApprovalAssessment
    explanation: str = ""
    core12_fingerprint: str
    ledger_hash: str = ""
    timestamp: str = Field(default_factory=utc_now_iso)


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    checks: dict[str, bool]
