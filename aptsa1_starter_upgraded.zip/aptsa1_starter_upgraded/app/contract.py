from __future__ import annotations

from .config import settings
from .core12 import CORE12_FINGERPRINT, sha256_hex, stable_json, CORE12
from .explain import render_explanation
from .models import (
    ActionRequest,
    ApprovalAssessment,
    DecisionResponse,
    DriftAssessment,
    PolicyAssessment,
    SandboxAssessment,
)
from .policy import PolicyEngine
from .sandbox import CapabilitySandbox


def assess_drift(declared_intent: str | dict, observed_action: str | dict) -> DriftAssessment:
    """
    APTSA1 field-by-field drift assessment.
    Compares four semantic dimensions: goal, scope, consent_basis, target_subject.
    String inputs are treated as goal-only declarations for backwards compatibility.
    """
    reasons: list[str] = []
    score = 0.0

    # Normalise: accept both plain strings and structured dicts
    if isinstance(declared_intent, str):
        declared_intent = {"goal": declared_intent.strip()}
    if isinstance(observed_action, str):
        observed_action = {"goal": observed_action.strip()}

    if not declared_intent.get("goal") and not observed_action.get("goal"):
        return DriftAssessment(score=0.0, reasons=[])

    # Goal divergence — highest weight
    if declared_intent.get("goal") != observed_action.get("goal"):
        score += 0.5
        reasons.append("Observed goal diverges from declared goal.")

    # Scope divergence
    if declared_intent.get("scope") and declared_intent.get("scope") != observed_action.get("scope"):
        score += 0.2
        reasons.append("Observed scope diverges from declared scope.")

    # Consent basis drift
    if declared_intent.get("consent_basis") and declared_intent.get("consent_basis") != observed_action.get("consent_basis"):
        score += 0.2
        reasons.append("Consent basis drift detected.")

    # Target subject changed
    if declared_intent.get("target_subject") and declared_intent.get("target_subject") != observed_action.get("target_subject"):
        score += 0.1
        reasons.append("Target subject changed between intent and action.")

    return DriftAssessment(score=round(min(score, 1.0), 3), reasons=reasons)


def assess_approval(request: ActionRequest, policy: PolicyAssessment) -> ApprovalAssessment:
    reasons: list[str] = []
    required = False
    if request.context.get("approval_required") is True:
        required = True
        reasons.append("Context explicitly requires approval.")
    if request.action in settings.approvals_required_actions:
        required = True
        reasons.append(f"Action '{request.action}' is on the approvals-required list.")
    if policy.violations and request.context.get("allow_degrade_without_approval") is not True:
        required = True
        reasons.append("Policy violations require review before execution.")
    return ApprovalAssessment(required=required, reasons=reasons)


def decide(request: ActionRequest) -> DecisionResponse:
    policy = PolicyEngine.assess(request)
    drift = assess_drift(request.declared_intent, request.observed_action)
    sandbox = CapabilitySandbox().assess(request)
    approval = assess_approval(request, policy)

    reasons: list[str] = []
    decision = "ALLOW"

    if CORE12_FINGERPRINT != sha256_hex(stable_json(CORE12)):
        decision = "HALT"
        reasons.append("Invariant fingerprint mismatch.")
    elif policy.critical:
        decision = "HALT" if any("Forbidden action" in m for m in policy.critical) else "DENY"
        reasons.extend(policy.critical)
    elif not sandbox.allowed:
        decision = "DENY"
        reasons.extend(sandbox.reasons)
    elif approval.required:
        decision = "PENDING_APPROVAL"
        reasons.extend(approval.reasons)
    elif drift.score >= 0.4 or policy.warnings:
        decision = "DEGRADE"
        reasons.extend(drift.reasons or [])
        reasons.extend(policy.warnings)
    else:
        reasons.append("No blocking invariant breach detected.")

    explanation = render_explanation(
        decision=decision,
        request=request,
        policy=policy,
        drift=drift,
        sandbox=sandbox,
        approval=approval,
    ) if request.require_explanation else ""

    return DecisionResponse(
        decision=decision,  # type: ignore[arg-type]
        reasons=reasons,
        policy=policy,
        drift=drift,
        sandbox=sandbox,
        approval=approval,
        explanation=explanation,
        core12_fingerprint=CORE12_FINGERPRINT,
    )
