from app.contract import decide
from app.models import ActionRequest, Core12Harms


def test_denies_unknown_capability():
    request = ActionRequest(
        action="dispatch_message",
        declared_intent="Send a message",
        observed_action="dispatch_message",
        context={"contains_personal_data": False, "consent_basis": "confirmed"},
        requested_capabilities=["shell_exec"],
    )
    response = decide(request)
    assert response.decision == "DENY"


def test_pending_approval_for_high_risk_action():
    request = ActionRequest(
        action="override_consent",
        declared_intent="Override consent",
        observed_action="override_consent",
        context={"contains_personal_data": True, "consent_basis": "confirmed"},
        requested_capabilities=["send_message"],
    )
    response = decide(request)
    assert response.decision in {"PENDING_APPROVAL", "DENY", "HALT"}


def test_core12_harm_blocks_or_denies():
    request = ActionRequest(
        action="send_message",
        declared_intent="Send content",
        observed_action="send_message",
        context={"contains_personal_data": False, "consent_basis": "confirmed"},
        core12_harms=Core12Harms(health=True),
        requested_capabilities=["send_message"],
    )
    response = decide(request)
    assert response.decision in {"DENY", "HALT"}
