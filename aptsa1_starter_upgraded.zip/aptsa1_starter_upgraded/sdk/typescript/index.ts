export type Decision =
  | "HALT"
  | "DENY"
  | "PENDING_APPROVAL"
  | "DEGRADE"
  | "ALLOW";

export interface ActionRequest {
  action: string;
  declared_intent?: string;
  observed_action?: string;
  context?: Record<string, unknown>;
  core12_harms?: Record<string, boolean>;
  requested_capabilities?: string[];
  require_explanation?: boolean;
}

export interface DecisionResponse {
  decision: Decision;
  reasons: string[];
  explanation: string;
  core12_fingerprint: string;
  ledger_hash: string;
}

export class Aptsa1Client {
  constructor(private readonly baseUrl: string) {}

  async decide(request: ActionRequest): Promise<DecisionResponse> {
    const response = await fetch(`${this.baseUrl}/v1/decide`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(request),
    });
    if (!response.ok) {
      throw new Error(`APTSA1 request failed: ${response.status}`);
    }
    return (await response.json()) as DecisionResponse;
  }
}
