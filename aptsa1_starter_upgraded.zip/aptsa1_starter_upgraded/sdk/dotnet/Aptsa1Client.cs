using System.Net.Http.Json;

namespace Aptsa1.Cleanroom;

public record ActionRequest(
    string Action,
    string? DeclaredIntent = null,
    string? ObservedAction = null,
    Dictionary<string, object>? Context = null,
    Dictionary<string, bool>? Core12Harms = null,
    List<string>? RequestedCapabilities = null,
    bool RequireExplanation = true
);

public record DecisionResponse(
    string Decision,
    List<string> Reasons,
    string Explanation,
    string Core12Fingerprint,
    string LedgerHash
);

public sealed class Aptsa1Client
{
    private readonly HttpClient _http;

    public Aptsa1Client(HttpClient http)
    {
        _http = http;
    }

    public async Task<DecisionResponse?> DecideAsync(ActionRequest request, CancellationToken cancellationToken = default)
    {
        var response = await _http.PostAsJsonAsync("/v1/decide", request, cancellationToken);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<DecisionResponse>(cancellationToken: cancellationToken);
    }
}
