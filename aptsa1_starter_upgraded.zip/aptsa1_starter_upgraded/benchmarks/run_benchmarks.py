from __future__ import annotations

import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.contract import decide
from app.models import ActionRequest, Core12Harms


def sample_requests() -> list[ActionRequest]:
    return [
        ActionRequest(
            action="dispatch_message",
            declared_intent="Send an appointment reminder",
            observed_action="dispatch_message",
            context={"contains_personal_data": True, "consent_basis": "confirmed"},
            requested_capabilities=["send_message"],
        ),
        ActionRequest(
            action="override_consent",
            declared_intent="Speed up the workflow",
            observed_action="override_consent",
            context={"contains_personal_data": True, "consent_basis": "missing"},
            requested_capabilities=["send_message"],
        ),
        ActionRequest(
            action="prepare_report",
            declared_intent="Summarise non-sensitive analytics",
            observed_action="exfiltrate_secret",
            context={"contains_personal_data": False, "consent_basis": "n/a"},
            requested_capabilities=["query_model", "read_context"],
            core12_harms=Core12Harms(security=True),
        ),
    ]


def main(iterations: int = 500) -> None:
    timings = []
    cases = sample_requests()
    for idx in range(iterations):
        request = cases[idx % len(cases)]
        started = time.perf_counter()
        decide(request)
        timings.append((time.perf_counter() - started) * 1000)
    print(
        {
            "iterations": iterations,
            "p50_ms": round(statistics.median(timings), 3),
            "mean_ms": round(statistics.mean(timings), 3),
            "max_ms": round(max(timings), 3),
        }
    )


if __name__ == "__main__":
    main()
